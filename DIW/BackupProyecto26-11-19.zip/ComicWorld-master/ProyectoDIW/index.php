<?php include("includes/a_config.php"); ?>
<!DOCTYPE>
<html>
    <head>
        <?php 
            include("includes/contenidoHead.php");
            include("includes/carousel.php");
        ?>


    </head>
    <body>

        <!--MENU DE NAVEGACION-->
        <?php include("includes/menuNav.php"); ?>

        <!--CARRUSEL-->
        <?php addCarousel("carrusel1", "carrusel2", "carrusel3", "carrusel4"); ?>
               
        <!--TARJETAS-->
        <div class="container-fluid mt-3">
            <!--Tarjetas-->
            <div class="row">

                <!--Primera columna-->

                <div class="col-sm-3">
                    <div class="card">
                        <img src="assets/img/imagenesTarjetas.PNG" class="card-img-top img-thumbnail border-0"/>
                        <div class="card-body text-justify">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                    </div>
                </div>

                <!--Segunda columna-->
                <div class="col-sm-3">
                    <div class="card">
                        <img src="assets/img/imagenesTarjetas.PNG" class="card-img-top img-thumbnail border-0"/>
                        <div class="card-body text-justify">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                    </div>
                </div>
                <!--Tercera columna-->
                <div class="col-sm-3">
                    <div class="card">
                        <img src="assets/img/imagenesTarjetas.PNG" class="card-img-bottom img-thumbnail border-0"/>
                        <div class="card-body text-justify">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                    </div>
                </div>
                
                <!--Cuarta columna-->
                <div class="col-sm-3">
                    <div class="card">
                        <img src="assets/img/imagenesTarjetas.PNG" class="card-img-bottom img-thumbnail border-0"/>
                        <div class="card-body text-justify">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

        <?php include("includes/footer.php"); ?>

    </body>
</html>

